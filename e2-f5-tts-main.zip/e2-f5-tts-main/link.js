module.exports = {
  run: [
    {
      method: "fs.link",
      params: {
        venv: "app/env"
      }
    }
  ]
}
