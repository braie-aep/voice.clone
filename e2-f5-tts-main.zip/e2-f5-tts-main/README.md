# e2-f5-tts

A pinokio script for https://huggingface.co/spaces/mrfakename/E2-F5-TTS

